package com.example.ai_radio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
