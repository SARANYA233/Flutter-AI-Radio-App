import 'package:flutter/material.dart';
import 'package:velocity_x/velocity_x.dart';

mixin AIColors {
  static Color primaryColor1 = Vx.yellow300;
  static Color primaryColor2 = Vx.purple900;
}
